export class Post {
    constructor(public id: string, public title: string, public abstract: string, public img: string,public date: Date) {

    }
}