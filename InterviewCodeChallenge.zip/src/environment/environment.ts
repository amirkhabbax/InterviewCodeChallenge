
export const defaultApi = "https://cdn.boghrat.com/api/codeChallenge/angular";